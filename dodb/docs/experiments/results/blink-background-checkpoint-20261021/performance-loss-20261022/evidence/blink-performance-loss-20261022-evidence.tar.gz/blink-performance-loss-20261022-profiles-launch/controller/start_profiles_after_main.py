import os, pathlib, subprocess, time
main=pathlib.Path('/bench/zfs/db/blink-performance-loss-20261022')
root=main.with_name(main.name+'-profiles')
while not (main/'matrix-complete.txt').exists():
    time.sleep(5)
assert len((main/'completed-cases.txt').read_text().splitlines())==24
environment=os.environ.copy()
environment.update(PYTHONDONTWRITEBYTECODE='1',DODB_LOSS_RUN_ROOT=str(root),DODB_LOSS_SMOKE='0',DODB_LOSS_CONTROLLER_SHA='b6dc7544bce98e2f0cdc2c516b74aec5dbf42256',DODB_LOSS_BASE_RUNNER=str(root/'controller/run_matrix_base.py'))
print('main completed; starting separate diagnostic profiles',flush=True)
subprocess.run(['python3','-u',str(root/'controller/run_profiles.py')],env=environment,check=True)
