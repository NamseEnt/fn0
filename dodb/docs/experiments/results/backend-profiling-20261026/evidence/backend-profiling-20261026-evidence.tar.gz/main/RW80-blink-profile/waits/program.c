
#include <uapi/linux/ptrace.h>
struct wait_start { u64 timestamp; s32 stack_id; u32 state; };
struct wait_key { u64 second; u32 thread_id; s32 stack_id; u32 runnable; };
struct aggregate { u64 count; u64 total_ns; u64 max_ns; u64 errors; u64 bytes; };
struct call_start { u64 timestamp; };
struct call_key { u64 second; u32 thread_id; u32 kind; };
struct name_value { char text[16]; };
BPF_HASH(wait_starts, u32, struct wait_start, 4096);
BPF_HASH(waits, struct wait_key, struct aggregate, 65536);
BPF_HASH(calls, struct call_key, struct aggregate, 65536);
BPF_HASH(thread_names, u32, struct name_value, 4096);
BPF_STACK_TRACE(stacks, 8192);
BPF_ARRAY(diagnostics, u64, 2);

TRACEPOINT_PROBE(sched, sched_switch) {
    u64 timestamp = bpf_ktime_get_ns();
    u64 identity = bpf_get_current_pid_tgid();
    u32 thread_id = identity;
    if ((identity >> 32) == 2112264) {
        struct wait_start entry = {};
        entry.timestamp = timestamp;
        entry.stack_id = stacks.get_stackid(args, 0);
        entry.state = args->prev_state;
        wait_starts.update(&thread_id, &entry);
        struct name_value name = {};
        bpf_get_current_comm(&name.text, sizeof(name.text));
        thread_names.update(&thread_id, &name);
    }
    u32 next_thread = args->next_pid;
    struct wait_start *entry = wait_starts.lookup(&next_thread);
    if (!entry) return 0;
    struct wait_key key = {};
    key.second = entry->timestamp / 1000000000;
    key.thread_id = next_thread;
    key.stack_id = entry->stack_id;
    key.runnable = entry->state == 0;
    struct aggregate empty = {};
    struct aggregate *value = waits.lookup_or_try_init(&key, &empty);
    if (value) {
        u64 duration = timestamp - entry->timestamp;
        __sync_fetch_and_add(&value->count, 1);
        __sync_fetch_and_add(&value->total_ns, duration);
        if (duration > value->max_ns) value->max_ns = duration;
    } else {
        u32 slot = 0;
        u64 *counter = diagnostics.lookup(&slot);
        if (counter) __sync_fetch_and_add(counter, 1);
    }
    wait_starts.delete(&next_thread);
    return 0;
}

BPF_HASH(start_fsync, u32, struct call_start, 4096);
TRACEPOINT_PROBE(syscalls, sys_enter_fsync) {
    u64 identity = bpf_get_current_pid_tgid();
    if ((identity >> 32) != 2112264) return 0;
    u32 thread_id = identity;
    struct call_start entry = {};
    entry.timestamp = bpf_ktime_get_ns();
    start_fsync.update(&thread_id, &entry);
    return 0;
}
TRACEPOINT_PROBE(syscalls, sys_exit_fsync) {
    u64 identity = bpf_get_current_pid_tgid();
    if ((identity >> 32) != 2112264) return 0;
    u32 thread_id = identity;
    struct call_start *entry = start_fsync.lookup(&thread_id);
    if (!entry) return 0;
    struct call_key key = {};
    key.second = entry->timestamp / 1000000000;
    key.thread_id = thread_id;
    key.kind = 0;
    struct aggregate empty = {};
    struct aggregate *value = calls.lookup_or_try_init(&key, &empty);
    if (value) {
        u64 duration = bpf_ktime_get_ns() - entry->timestamp;
        __sync_fetch_and_add(&value->count, 1);
        __sync_fetch_and_add(&value->total_ns, duration);
        if (duration > value->max_ns) value->max_ns = duration;
        if (args->ret < 0) __sync_fetch_and_add(&value->errors, 1);
        if (args->ret > 0 && (0 == 2 || 0 == 3))
            __sync_fetch_and_add(&value->bytes, args->ret);
    } else {
        u32 slot = 1;
        u64 *counter = diagnostics.lookup(&slot);
        if (counter) __sync_fetch_and_add(counter, 1);
    }
    start_fsync.delete(&thread_id);
    return 0;
}

BPF_HASH(start_fdatasync, u32, struct call_start, 4096);
TRACEPOINT_PROBE(syscalls, sys_enter_fdatasync) {
    u64 identity = bpf_get_current_pid_tgid();
    if ((identity >> 32) != 2112264) return 0;
    u32 thread_id = identity;
    struct call_start entry = {};
    entry.timestamp = bpf_ktime_get_ns();
    start_fdatasync.update(&thread_id, &entry);
    return 0;
}
TRACEPOINT_PROBE(syscalls, sys_exit_fdatasync) {
    u64 identity = bpf_get_current_pid_tgid();
    if ((identity >> 32) != 2112264) return 0;
    u32 thread_id = identity;
    struct call_start *entry = start_fdatasync.lookup(&thread_id);
    if (!entry) return 0;
    struct call_key key = {};
    key.second = entry->timestamp / 1000000000;
    key.thread_id = thread_id;
    key.kind = 1;
    struct aggregate empty = {};
    struct aggregate *value = calls.lookup_or_try_init(&key, &empty);
    if (value) {
        u64 duration = bpf_ktime_get_ns() - entry->timestamp;
        __sync_fetch_and_add(&value->count, 1);
        __sync_fetch_and_add(&value->total_ns, duration);
        if (duration > value->max_ns) value->max_ns = duration;
        if (args->ret < 0) __sync_fetch_and_add(&value->errors, 1);
        if (args->ret > 0 && (1 == 2 || 1 == 3))
            __sync_fetch_and_add(&value->bytes, args->ret);
    } else {
        u32 slot = 1;
        u64 *counter = diagnostics.lookup(&slot);
        if (counter) __sync_fetch_and_add(counter, 1);
    }
    start_fdatasync.delete(&thread_id);
    return 0;
}

BPF_HASH(start_pwrite64, u32, struct call_start, 4096);
TRACEPOINT_PROBE(syscalls, sys_enter_pwrite64) {
    u64 identity = bpf_get_current_pid_tgid();
    if ((identity >> 32) != 2112264) return 0;
    u32 thread_id = identity;
    struct call_start entry = {};
    entry.timestamp = bpf_ktime_get_ns();
    start_pwrite64.update(&thread_id, &entry);
    return 0;
}
TRACEPOINT_PROBE(syscalls, sys_exit_pwrite64) {
    u64 identity = bpf_get_current_pid_tgid();
    if ((identity >> 32) != 2112264) return 0;
    u32 thread_id = identity;
    struct call_start *entry = start_pwrite64.lookup(&thread_id);
    if (!entry) return 0;
    struct call_key key = {};
    key.second = entry->timestamp / 1000000000;
    key.thread_id = thread_id;
    key.kind = 2;
    struct aggregate empty = {};
    struct aggregate *value = calls.lookup_or_try_init(&key, &empty);
    if (value) {
        u64 duration = bpf_ktime_get_ns() - entry->timestamp;
        __sync_fetch_and_add(&value->count, 1);
        __sync_fetch_and_add(&value->total_ns, duration);
        if (duration > value->max_ns) value->max_ns = duration;
        if (args->ret < 0) __sync_fetch_and_add(&value->errors, 1);
        if (args->ret > 0 && (2 == 2 || 2 == 3))
            __sync_fetch_and_add(&value->bytes, args->ret);
    } else {
        u32 slot = 1;
        u64 *counter = diagnostics.lookup(&slot);
        if (counter) __sync_fetch_and_add(counter, 1);
    }
    start_pwrite64.delete(&thread_id);
    return 0;
}

BPF_HASH(start_pread64, u32, struct call_start, 4096);
TRACEPOINT_PROBE(syscalls, sys_enter_pread64) {
    u64 identity = bpf_get_current_pid_tgid();
    if ((identity >> 32) != 2112264) return 0;
    u32 thread_id = identity;
    struct call_start entry = {};
    entry.timestamp = bpf_ktime_get_ns();
    start_pread64.update(&thread_id, &entry);
    return 0;
}
TRACEPOINT_PROBE(syscalls, sys_exit_pread64) {
    u64 identity = bpf_get_current_pid_tgid();
    if ((identity >> 32) != 2112264) return 0;
    u32 thread_id = identity;
    struct call_start *entry = start_pread64.lookup(&thread_id);
    if (!entry) return 0;
    struct call_key key = {};
    key.second = entry->timestamp / 1000000000;
    key.thread_id = thread_id;
    key.kind = 3;
    struct aggregate empty = {};
    struct aggregate *value = calls.lookup_or_try_init(&key, &empty);
    if (value) {
        u64 duration = bpf_ktime_get_ns() - entry->timestamp;
        __sync_fetch_and_add(&value->count, 1);
        __sync_fetch_and_add(&value->total_ns, duration);
        if (duration > value->max_ns) value->max_ns = duration;
        if (args->ret < 0) __sync_fetch_and_add(&value->errors, 1);
        if (args->ret > 0 && (3 == 2 || 3 == 3))
            __sync_fetch_and_add(&value->bytes, args->ret);
    } else {
        u32 slot = 1;
        u64 *counter = diagnostics.lookup(&slot);
        if (counter) __sync_fetch_and_add(counter, 1);
    }
    start_pread64.delete(&thread_id);
    return 0;
}

BPF_HASH(start_futex, u32, struct call_start, 4096);
TRACEPOINT_PROBE(syscalls, sys_enter_futex) {
    u64 identity = bpf_get_current_pid_tgid();
    if ((identity >> 32) != 2112264) return 0;
    u32 thread_id = identity;
    struct call_start entry = {};
    entry.timestamp = bpf_ktime_get_ns();
    start_futex.update(&thread_id, &entry);
    return 0;
}
TRACEPOINT_PROBE(syscalls, sys_exit_futex) {
    u64 identity = bpf_get_current_pid_tgid();
    if ((identity >> 32) != 2112264) return 0;
    u32 thread_id = identity;
    struct call_start *entry = start_futex.lookup(&thread_id);
    if (!entry) return 0;
    struct call_key key = {};
    key.second = entry->timestamp / 1000000000;
    key.thread_id = thread_id;
    key.kind = 4;
    struct aggregate empty = {};
    struct aggregate *value = calls.lookup_or_try_init(&key, &empty);
    if (value) {
        u64 duration = bpf_ktime_get_ns() - entry->timestamp;
        __sync_fetch_and_add(&value->count, 1);
        __sync_fetch_and_add(&value->total_ns, duration);
        if (duration > value->max_ns) value->max_ns = duration;
        if (args->ret < 0) __sync_fetch_and_add(&value->errors, 1);
        if (args->ret > 0 && (4 == 2 || 4 == 3))
            __sync_fetch_and_add(&value->bytes, args->ret);
    } else {
        u32 slot = 1;
        u64 *counter = diagnostics.lookup(&slot);
        if (counter) __sync_fetch_and_add(counter, 1);
    }
    start_futex.delete(&thread_id);
    return 0;
}
